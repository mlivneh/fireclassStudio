// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyByKMGr2knkWL8Ps_4DoA9KOJ8Ta0IjN-I",
  authDomain: "fireclassstudio.firebaseapp.com",
  projectId: "fireclassstudio",
  storageBucket: "fireclassstudio.firebasestorage.app",
  messagingSenderId: "900608873995",
  appId: "1:900608873995:web:130533a437b1f168f7190e",
  measurementId: "G-RN24RDVPJ4"
};